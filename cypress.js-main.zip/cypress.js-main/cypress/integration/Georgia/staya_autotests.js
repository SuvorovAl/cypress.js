describe ('Проверка формы авторизации', function () {

    it('Позитивный кейс: Авторизация', function() {
cy.visit('https://staya.dog/');

cy.get('.header-bottom__right--link').click();
cy.get('.auth-form__submit').should('be.disabled');
cy.get('.auth-form > form > [type="email"]').type('suvorov389@gmail.com');
cy.get('.auth-form > form > [type="password"]').type('Ads123');
cy.get('.auth-form__submit').click();

cy.contains('Мои заказы');

    })

    it('Негативный кейс: Неверный пароль', function() {
        
        cy.get('button.profile__nav-link').click();
        cy.get('.box__button_ok').click();
        cy.reload();
        cy.get('.header-bottom__right--link').click();
        cy.get('.auth-form__submit').should('be.disabled');
        cy.get('.auth-form > form > [type="email"]').type('suvorov389@gmail.com');
        cy.get('.auth-form > form > [type="password"]').type('ads120');
        cy.get('.auth-form__submit').click();
        
        cy.get('.error-label');
        cy.contains('Невозможно войти с предоставленными учетными данными');
        
            })


})