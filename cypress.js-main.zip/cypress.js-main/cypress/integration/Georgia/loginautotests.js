describe ('Проверка формы авторизации', function () {

    it('Позитивный кейс: Логика восстановления пароля', function() {
cy.visit('https://login.qa.studio/');

cy.get('#forgotEmailButton').click();
cy.get('#mailForgot').type('german@dolnikov.ru');
cy.get('#restoreEmailButton').click();

cy.contains('Успешно отправили пароль на e-mail');
cy.get('#exitMessageButton > .exitIcon').click();
cy.contains('Форма логина');

    })
    it('Позитивный кейс: Авторизация проходит упешно', function() {
        cy.reload();
        cy.get('#mail').type('german@dolnikov.ru');
        cy.get('#loginButton').should('be.disabled');
        cy.get('#pass').type('iLoveqastudio1');
        cy.get('#loginButton').should('not.be.disabled');
        cy.get('#loginButton').click();

        cy.contains('Авторизация прошла успешно');
        cy.get('#exitMessageButton > .exitIcon').click();
        cy.contains('Форма логина');

    })

    it('Негативный кейс кейс: Неправильный пароль', function() {
        cy.reload();
        cy.get('#mail').type('german@dolnikov.ru');
        cy.get('#loginButton').should('be.disabled');
        cy.get('#pass').type('iLoveqastudio2');
        cy.get('#loginButton').should('not.be.disabled');
        cy.get('#loginButton').click();

        cy.contains('Такого логина или пароля нет');
        cy.get('#exitMessageButton > .exitIcon').click();
        cy.contains('Форма логина');

    })

    it('Негативный кейс: Неправильный логин', function() {
        cy.reload();
        cy.get('#mail').type('german@d.ru');
        cy.get('#loginButton').should('be.disabled');
        cy.get('#pass').type('iLoveqastudio1');
        cy.get('#loginButton').should('not.be.disabled');
        cy.get('#loginButton').click();

        cy.contains('Такого логина или пароля нет');
        cy.get('#exitMessageButton > .exitIcon').click();
        cy.contains('Форма логина');

    })


    })
